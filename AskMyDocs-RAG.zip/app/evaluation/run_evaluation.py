from app.evaluation.evaluator import run_evaluation

if __name__ == "__main__":
    run_evaluation()
