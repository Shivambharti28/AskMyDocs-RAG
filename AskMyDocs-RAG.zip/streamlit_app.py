import streamlit as st
from app.services.retrieval.rag_pipeline import ask

st.set_page_config(
    page_title="Enterprise RAG",
    page_icon="📚",
    layout="wide",
)

st.title("📚 Enterprise RAG")

question = st.text_input(
    "Ask a question about your documents"
)

if st.button("Ask"):
    result = ask(question)
    st.write(result["answer"])